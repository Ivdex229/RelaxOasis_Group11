from MyMQTT import *
import time
import json
import random
from simplePublisher import *
from simpleSubscriber import *
import requests
import sys
import cherrypy
import threading
from statistics import mean
import numpy as np
import os

service_catalog_url = os.getenv('SERVICE_CATALOG_URL', 'http://service-catalog:8080')
resource_catalog_url = os.getenv('RESOURCE_CATALOG_URL', 'http://resource-catalog-1:8081')


# REST communication
class temperatureREST(object):
    def __init__(self):
        self.last_10_seconds_data = []
        self.threshold = 30

    exposed = True



    def GET(self, *uri, **parameters):
        if len(uri) == 1 and uri[0] == "temperature":
            if len(self.last_10_seconds_data) < 2:
                std = 0
            else:
                std = np.std(self.last_10_seconds_data)
                
            # Contare gli elementi che superano la soglia
            count = 0
            for data_point in self.last_10_seconds_data:
                if data_point > self.threshold:
                    count += 1
            
            statistics_info = (
                    f'The following values are referred to the last 10 measurements:\n'
                    f'  \u2022 Mean temperature level:                  {round(mean(self.last_10_seconds_data),2)} °C\n'
                    f'  \u2022 STD temperature level:                   {round(std,2)} °C\n'
                    f'  \u2022 Max temperature level:                   {round(max(self.last_10_seconds_data),2)} °C\n'
                    f'  \u2022 Min temperature level:                   {round(min(self.last_10_seconds_data),2)} °C\n',
                    f'  \u2022 Number of elements that exceeds the threshold in the last 10 measurements: : {count}\n'
                )
            return statistics_info


    def update_data(self, value):
        self.last_10_seconds_data.append(value)
        if len(self.last_10_seconds_data) > 10:
            self.last_10_seconds_data.pop(0)

class SensorControl(MyPublisher):
    def __init__(self, clientID, sensortype, sensorID, measure, broker, port, topic):
        self.clientID = clientID + '_temp'
        self.sensortype = sensortype
        self.sensorID = sensorID
        self.measure = measure
        self.topic = topic
        self.client = MyMQTT(self.sensorID, broker, port, None)

        self.__message = {
            'bn': self.topic,
            'e': [
                {
                    'type': self.sensortype,
                    'unit': self.measure,
                    'timestamp': '',
                    'value': ' '
                }
            ]
        }

    def start(self):
        self.client.start()

    def stop(self):
        self.client.stop()

    def publish(self, value):
        message = self.__message
        message['e'][0]['value'] = value
        message['e'][0]['timestamp'] = str(time.time())
        self.client.myPublish(self.topic, json.dumps(message))
        print("published\n" + json.dumps(message))

setting_file = "conf_temperature.json"
service_file = "service_catalog_info.json"
NAME_OWNER = "1"  # Modify this according to your needs
def registration(setting_file, service_file,number_owner, name_owner):
    with open(setting_file,"r") as f1:
        conf=json.loads(f1.read())

    with open(service_file,"r") as f2:
        conf_service=json.loads(f2.read())
    
    requeststring = f"{service_catalog_url}/N_res_cat?N={int(number_owner) - 1}"
    r = requests.get(requeststring)
    print('REQUESTED INFO ABOUT RESOURCE CATALOGUE')
    print()
    rc = json.loads(r.text)
    print('RESOURCE CATALOGUE: ', rc)
    rc_ip = rc["ip_address"]
    rc_ip_port = rc["ip_port"]
    poststring = f"{resource_catalog_url}/device"
    rc_broker = rc["broker"]
    rc_broker_port = rc["broker_port"]
    rc_owner = rc["owner"]            # ex. relax_room_politecnico
    rc_basetopic = rc["base_topic"]   # ex. room
    
    #sensor_type=""
    #for entry in conf["sensor_type"]:
    #    sensor_type=sensor_type+entry+"_"
    
    sensor_model=conf["sensor_model"]
    #sensor_measure=""
    #for entry in conf["measure"]:
    #    sensor_measure=sensor_measure+"_"+entry

    requeststring = f"{service_catalog_url}/base_topic"
    sbt=requests.get(requeststring)

    service_b_t=json.loads(sbt.text)
    topic=[]
    body=[]
    index=0
    for i in conf["sensor_type"]:
        print('MEASURE: ', i)
        topic.append(name_owner + '/' + rc_basetopic + "/" + i + "/" + conf["sensor_id"])
        body_dic = {
            "owner": name_owner,
            "sensor_id": conf['sensor_id'],
            "sensor_type": conf['sensor_type'],
            "measure": conf["measure"][index],
            "end-points": {
                "basetopic": service_b_t,
                "complete_topic": topic,
                "broker": rc["broker"],
                "port": rc["broker_port"]
            }
        }
        body.append(body_dic)
        requests.post(poststring, json.dumps(body[index]))
        print('BODY: ', json.dumps(body[index]))
        index = index + 1
    print('POSTED INFO ABOUT DEVICES')
    print()

    return rc_basetopic, conf["sensor_type"], conf["sensor_id"], topic, conf["measure"], rc_broker, rc_broker_port, sensor_model

def simulate_temperature_data():
    while True:
        a = 15
        b = 35
        mean = (a + b) / 2  
        std = (b - a) / 6  

        # Causal values with gaussian distribution
        simulated_temperature_level = round(np.random.normal(mean, std), 3)

        # Inside the while loop where simulated_temperature_level is obtained, update temperatureRESTManager data
        print()
        print('Simulated temperature Level={0:0.1f}'.format(simulated_temperature_level))
        temperatureRESTManager.update_data(simulated_temperature_level)
        Sensor[0].publish('{0:0.1f}'.format(simulated_temperature_level))

        if simulated_temperature_level > 30:
            print('Too much temperature! Implementing temperature control measures...')

        time.sleep(5)
        
if __name__ == "__main__":
    service_catalog_info = "service_catalog_info.json"
    service_catalog_info = json.load(open(service_catalog_info))
    service_get_string = f"{service_catalog_url}/res_cat"
    rooms_all=json.loads(requests.get(f"{service_catalog_url}/res_cat").text)
    print('Which relax room do you want to select?')
    N_rooms = len(rooms_all)
    for i in range(N_rooms):
        print(f"{i + 1} ---> {rooms_all[i]['owner']}")
    while True:
        try:
            number_owner = int(input('Enter the room number \n'))
            if number_owner < 1 or number_owner > N_rooms:
                print('Error: Number out of range')

            else:
                name_owner = rooms_all[number_owner - 1]["owner"]
                print(f"Selected owner: {name_owner}")
                break
        except ValueError:
            print('Error: Invalid input, please enter a number')
            name_owner = rooms_all[int(number_owner) - 1]["owner"]

            # ------------ MQTT -----------------------
    clientID, sensortype, sensorID, topic, measure, broker, port, sensor_model = registration(setting_file, service_file,number_owner, name_owner)
    #clientID, sensortype, sensorID, topic, measure, broker, port, sensor_model = registration("conf_light.json", "service_catalog_info_1.json")

    # Create instances of SensorControl
    index = 0
    Sensor = []
    for i in sensortype:
        Sensor.append(SensorControl(clientID, i, sensorID, measure[index], broker, port, topic[index]))
        Sensor[index].start()
        index += 1

    # ------------ REST -----------------------
    temperatureRESTManager = temperatureREST()

    conf = {
        '/': {
            'request.dispatch': cherrypy.dispatch.MethodDispatcher(),
            'tools.sessions.on': True,
        }
    }
    
    current_dir = os.path.dirname(os.path.abspath(__file__))
    service_dev = os.path.join(current_dir, "conf_temperature.json")
    with open(service_dev,"r") as f2:    
        conf_service=json.loads(f2.read())
    
    cherrypy.tree.mount(temperatureRESTManager, '/', conf)
    cherrypy.config.update(conf)
    cherrypy.config.update({'server.socket_host': '0.0.0.0'})
    cherrypy.config.update({"server.socket_port": int(conf_service['ip_port_service'])+int(number_owner)})
    cherrypy.engine.start()

    # Avvia il thread per simulare i dati sulla rumore
    simulate_thread = threading.Thread(target=simulate_temperature_data)
    simulate_thread.start()

    cherrypy.engine.block()
