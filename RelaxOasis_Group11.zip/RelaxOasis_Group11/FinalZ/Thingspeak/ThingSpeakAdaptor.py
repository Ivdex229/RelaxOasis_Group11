import datetime
import pytz
import time
import json
import requests
from MyMQTT import MyMQTT
import sys
import os

service_catalog_url = os.getenv('SERVICE_CATALOG_URL', 'http://service-catalog:8080')
resource_catalog_url = os.getenv('RESOURCE_CATALOG_URL', 'http://resource-catalog-1:8081')


class ThingSpeak_API:
    def __init__(self, think):
        self.api_key = think['key']
        self.url = think['url']
        self.url_channels = think['url_channels']
        self.channel_name = ''

    def get_channel_list(self):
        url = f"https://api.thingspeak.com/channels.json?api_key={self.api_key}"
        response = requests.get(url)
        if response.status_code == 200:
            channel_list = response.json()
            return channel_list
        else:
            print(f"Error: {response.status_code} - {response.text}")
            return None

    def create_channel(self, owner):
        response = requests.post(
            self.url_channels,
            json={
                "api_key": self.api_key,
                "name": owner,
                "field1": "Temperature",
                "field2": "Humidity",
                "field3": "Noise",
                "field4": "Brightness",
                "public_flag": True  # Set the channel to be public
            }
        )
        if response.status_code == 200:
            print(f"Channel '{owner}' created.")
            data = response.json()
            channel_id = data["id"]
            write_key = data['api_keys'][0]['api_key']
            return channel_id, write_key
        else:
            print(f"Error during the creation of the '{owner}': {response.text}")
            return None, None


class ThinkSpeak:
    def __init__(self, clientID, broker, port, channel, write_key):
        self.client = MyMQTT(clientID, broker, port, self)
        self.status = None
        self.channel = channel
        self.write_key = write_key
        self.ID = f"{self.channel}_TS-Adaptor"
        self.type = "TS-Adaptor"
        self.broker_address = broker
        self.field1_data = None  # Temperature
        self.field2_data = None  # Humidity
        self.field3_data = None  # Noise
        self.field4_data = None  # Brightness

    def start(self, topic):
        self.topic = topic
        self.client.start()
        self.client.mySubscribe(self.topic)

    def stop(self):
        self.client.stop()

    def notify(self, topic, msg):
        d = json.loads(msg.decode('utf8'))
        print(d)
        if d["e"][0]["type"] == "temperature":
            self.field1_data = d["e"][0]["value"]
            print('NEW VALUE temp: ', self.field1_data)
        elif d["e"][0]["type"] == "humidity":
            self.field2_data = d["e"][0]["value"]
            print('NEW VALUE hum: ', self.field2_data)
        elif d["e"][0]["type"] == "noise":
            self.field3_data = d["e"][0]["value"]
            print('NEW VALUE noise: ', self.field3_data)
        elif d["e"][0]["type"] == "brightness":
            self.field4_data = d["e"][0]["value"]
            print('NEW VALUE brig: ', self.field4_data)


def rooms_sensors(service_catalog_info):
    service_get_string = f"{service_catalog_url}/res_cat"
    print("INFORMATION FROM SERVICE CATALOG RECEIVED!\n")
    rooms_all = json.loads(requests.get(service_get_string).text)
    rooms = []

    for entry in rooms_all:
        request_string = f"{resource_catalog_url}/alldevices"
        devices = json.loads(requests.get(request_string).text)
        sensors = []
        for dev in devices:
            for type in dev["sensor_type"]:
                if type != 'fiscal_code' and dev["owner"] == entry["owner"]:
                    sensors.append(type)
        room = {
            "room_name": entry["base_topic"],
            "room_sensors": sensors
        }
        found = 0
        for own in rooms:
            if own['owner'] == entry['owner']:
                own['rooms'].append(room)
                found = 1
        if found == 0:
            rooms.append({
                'owner': entry['owner'],
                'rooms': [room]
            })
    print("INFORMATION OF RESOURCE CATALOG (room) RECEIVED!\n")

    print(f"Available owners and rooms:")
    for i in range(len(rooms)):
        print(f'     {rooms[i]["owner"]}')
    chosen_owner = input('Owner: ')

    for room in rooms:
        if room["owner"] == chosen_owner:
            print()
            print(f"Choose a room for owner '{chosen_owner}':")
            for r in room["rooms"]:
                print(f'     {r["room_name"]}')
            break
    else:
        print("Invalid owner. Please choose from the list.")

    chosen_room = input('\nRoom: ')

    for owner in rooms:
        if owner["owner"] == chosen_owner:
            for room in owner["rooms"]:
                if room["room_name"] == chosen_room:
                    return owner["owner"], room["room_name"]


if __name__ == "__main__":
    headers = {'Content-type': 'application/json', 'Accept': 'raw'}
    service_catalog_info = json.load(open("service_catalog_info.json"))

    think = json.load(open("conf_thinkgspeak.json"))
    thingspeak_rest = ThingSpeak_API(think)
    channel_list = thingspeak_rest.get_channel_list()
    if len(channel_list) > 0:
        print('List ThingSpeak channels already created:')
    for element in channel_list:
        print(f'     {element["name"]}')
    print()
    time.sleep(1)

    new_channel_name, room = rooms_sensors(service_catalog_info)
    for element in channel_list:
        if new_channel_name == element["name"]:
            print('Channel already created, you can visualize data on ThingSpeak')
            sys.exit()

    channel_id, write_key = thingspeak_rest.create_channel(new_channel_name)
    if channel_id is None or write_key is None:
        print("Error")
        exit()

    topic_to_subscribe = f"{new_channel_name}/{room}/#"  # SUBSCRIBING TO TOPIC AFTER OBTAINING THE NEEDED INFORMATION FROM rooms_sensors METHOD
    print('TOPIC: ', topic_to_subscribe)

    tp = ThinkSpeak(new_channel_name, think["broker"], think["port1"], channel_id, write_key)

    tp.start(topic_to_subscribe)
    count = 0
    t = 0
    while t < 80:
        current_time = (datetime.datetime.now(pytz.timezone('Europe/Rome')) - datetime.timedelta(hours=2)).strftime(
            "%d-%m-%Y %H:%M:%S")
        data_upload = json.dumps({
            "api_key": tp.write_key,
            "channel_id": tp.channel,
            "created_at": current_time,
            "entry_id": count,
            "field1": tp.field1_data,  # temperature
            "field2": tp.field2_data,  # humidity
            "field3": tp.field3_data,  # noise
            "field4": tp.field4_data  # brightness
        })

        requests.post(url=think["url"], data=data_upload, headers=headers)
        print("\nINFORMATION SENT TO THINGSPEAK!\n")
        time.sleep(30)
        count += 1
        t += 1

    tp.stop()
