import json
import cherrypy
import datetime
import requests
import time
import sys
import os

service_catalog_url = os.getenv('SERVICE_CATALOG_URL', 'http://service-catalog:8080')

class ResourceCatalogManager(object):
    def __init__(self, users_file, devices_file, service_file, setting_file):
        self.usersFile=users_file
        self.users=json.load(open(self.usersFile))
        self.devicesFile=devices_file                               # devices_file = "resource_catalog_devices.json"
        self.devices=json.load(open(self.devicesFile))
        self.settingsFile=setting_file                              # setting_file = "resource_catalog_settings.json"
        self.settings=json.load(open(self.settingsFile))
        self.service_file=service_file                              # service_file = "service_catalog_info.json"
        self.service_info=json.load(open(self.service_file))
        
        # Add info about owner (resource_catalog_settings) in service_catalog_info
        poststring = f"{service_catalog_url}"
        requests.post(poststring, json.dumps(self.settings))

    exposed=True
    
    def GET(self, *uri, **parameters):
        if len(uri)==1 and len(parameters)<2 :
            if uri[0]=='alldevices':
                return self.viewAllDevices()
            elif uri[0]=='allusers':
                return self.viewAllUsers()
            elif uri[0]=='user':
                output=self.searchUserByUserID(parameters['user_id'])
                if output=={}:
                    output='user not found'
                return output
            elif uri[0]=='device':
                output=self.searchDevicesByDeviceID(parameters['device_id'])
                if output=={}:
                    raise cherrypy.HTTPError(400, 'device not found')
                return output
            else:
                raise cherrypy.HTTPError(400, 'incorrect URI' + {uri[0]} + ', expected alldevices, allusers, device or user')

        else:
            raise cherrypy.HTTPError(400, 'incorrect URI or PARAMETERS URI' + {len(uri)} + 'PAR {len(parameters)}')
    
    def POST(self, *uri, **parameters):
        if len(uri)==1 : 
            print('POST')            
            body=cherrypy.request.body.read()
            json_body=json.loads(body)

            if(uri[0]=='device'):
                #print('NEW DEVICE')
                if self.searchDevicesByDeviceOwner_ID(json_body['owner'], json_body['sensor_id']) !={}:
                    print('device already present')
                    raise cherrypy.HTTPError(400, 'device already present')
                print(json_body)
                # Add info about devices in resource_catalog_devices
                #print('INSERT DEVICE')
                self.insertDevice(json_body)
                self.devices=json.load(open(self.devicesFile))              
            
            elif(uri[0]=='user'):
                if self.searchUserByUserID(json_body['user_id']) !={}:
                    raise cherrypy.HTTPError(400, 'user already present')
                self.insertUser(json_body)
                self.devices=json.load(open(self.devicesFile))             
            else:
                raise cherrypy.HTTPError(400, 'invalid uri')  
                
        else:
            raise cherrypy.HTTPError(400, 'incorrect URI or PARAMETERS')    
        
    def PUT(self, *uri, **parameters):
        if len(uri)==1 :             
            body=cherrypy.request.body.read()
            json_body=json.loads(body)   
            if(uri[0]=='device'):
                if self.searchDevicesByDeviceOwner_ID(json_body['owner'], json_body['sensor_id']) !={}:
                    self.updateDeviceInfo(json_body)
                else:
                    self.insertDevice(json_body)
                    #print('PUT DEVICES ', self.devices)
                self.devices=json.load(open(self.devicesFile))      
            elif(uri[0]=='user'):
                if self.searchUserByUserID(json_body['user_id']) !='{}':
                    self.updateUserInfo(json_body)
                else:
                    self.insertUser(json_body)
                self.devices=json.load(open(self.usersFile))      
            else:
                raise cherrypy.HTTPError(400, 'invalid uri')  
                
        else:
            raise cherrypy.HTTPError(400, 'incorrect URI or PARAMETERS')   
    
    def viewAllDevices(self):
        return json.dumps(self.devices)        

    def viewAllUsers(self):
        return json.dumps(self.users)
    
    def searchDevicesByDeviceOwner_ID(self, owner, ID):
        for dev in self.devices:
            if(dev['sensor_id']==ID and dev['owner']==owner):
                return json.dumps(dev)   
        return {}                               

    def searchUserByUserID(self, ID):
        for user in self.users:
            if(user['user_id']==ID):
                return json.dumps(user)
        return {}  
                
    def updateDeviceInfo(self,device):
        if len(self.devices)==0:
            return {}
        for dev in self.devices:
            if dev['ID']==device['ID']:
                dev['end-points']=device['end-points']
                dev['available_resources']=device['available_resources']
                dev['insert-timestamp']=time.time()
                break
        with open(self.devicesFile, "w") as f:
            json.dump(self.devices, f)
    
    def updateUserInfo(self,user):
        for us in self.users:
            if us['ID']==user['ID']:
                us['name']=user['name']
                us['surname']=user['surname']
                us['email']=user['email']
                break
        with open(self.usersFile, "w") as f:
            json.dump(self.users, f)

    def insertDevice(self, device):
        device['insert-timestamp']=time.time()
        self.devices.append(device)
        with open(self.devicesFile, "w") as f:
            json.dump(self.devices, f) 
        return
    
    def insertUser(self, user):
        self.users.append(user)
        with open(self.usersFile, "w") as f:
            json.dump(self.users, f)
        return

    def removeDevices(self):
        young_devices=[]
        for dev in self.devices:
            print(dev)

            if float(dev['insert-timestamp'])-float(time.time())<1200:
                young_devices.append(dev)
        self.devices=young_devices

        
if __name__=="__main__":
    setting_file = sys.argv[1] # "resource_catalog_settings_NR.json"
    devices_file = sys.argv[2] # "resource_catalog_devices_NR.json"
    users_file   = "resource_catalog_users_1.json"
    service_file = "service_catalog_info.json"

    conf={
        '/': {
            'request.dispatch': cherrypy.dispatch.MethodDispatcher(),
            'tools.sessions.on': True, 
        }
    }
    settings = json.load(open(setting_file))
    rcm = ResourceCatalogManager(users_file, devices_file, service_file, setting_file)
    cherrypy.tree.mount(rcm,'/', conf)
    cherrypy.config.update(conf)
    cherrypy.config.update({'server.socket_host': '0.0.0.0'})
    cherrypy.config.update({"server.socket_port":int(settings['ip_port'])})
    cherrypy.engine.start()
    while 1:
        rcm.removeDevices()
        time.sleep(120)
    cherrypy.engine.block()    