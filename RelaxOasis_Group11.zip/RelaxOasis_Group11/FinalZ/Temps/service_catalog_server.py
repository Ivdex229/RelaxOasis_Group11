import json
import cherrypy
import datetime
import requests
 #docker
class ServiceCatalogManager(object):
    def __init__(self):
        self.settings = "service_catalog_settings.json"
        self.conf = json.load(open(self.settings))

    exposed = True

    def reload_config(self):
        """Reload the configuration from the settings JSON file."""
        self.conf = json.load(open(self.settings))

    def GET(self, *uri, **parameters):
        print('GET')
        if len(uri) == 1:
            self.settings = "service_catalog_settings.json"
            self.conf = json.load(open(self.settings))

            if uri[0] == 'res_cat':
                return json.dumps(self.conf["resource_catalogs"])  # restituisce tutti i resource catalogs

            elif uri[0] == 'one_res_cat':  # restituisce l'ultimo resource catalog
                results = self.conf['resource_catalogs'][len(self.conf["resource_catalogs"]) - 1]
                return json.dumps(results)

            elif uri[0] == 'N_res_cat':  # restituisce il N-esimo resource catalog
                par = parameters.get('N')
                results = self.conf['resource_catalogs'][int(par)]
                return json.dumps(results)

            elif uri[0] == 'broker':
                output_site = self.conf['broker']
                output_port = self.conf['broker_port']
                output = {
                    'broker_port': output_port,
                    'broker': output_site,
                }
                print(output)
                return output

            elif uri[0] == 'base_topic':
                return json.dumps(self.conf["base_topic"])

        else:
            error_string = "incorrect URI or PARAMETERS URI"
            raise cherrypy.HTTPError(400, error_string)

    def POST(self, *uri, **parameters):
        # Reload before processing the new POST request
        self.reload_config()
        if len(uri) == 0:
            body = cherrypy.request.body.read()
            json_body = json.loads(body)
            self.insertResCat(json_body)
            cherrypy.response.headers['Content-Type'] = 'application/json'
        else:
            raise cherrypy.HTTPError(400, "Incorrect URI or PARAMETERS")

    def insertResCat(self, json_body):
        # Check for uniqueness based on a unique attribute like 'ip_port'
        existing_ports = [catalog["ip_port"] for catalog in self.conf['resource_catalogs']]
        if json_body["ip_port"] not in existing_ports:
            print('NEW RESOURCE: ', json_body)
            self.conf['resource_catalogs'].append(json_body)
            with open(self.settings, "w") as f:
                json.dump(self.conf, f)
        else:
            print('RESOURCE ALREADY EXISTS: ', json_body)

    def getPort(self):
        return self.conf['ip_port']

    def getBrokerPort(self):
        return self.conf['broker_port']


if __name__ == "__main__":
    service_info = json.load(open('service_catalog_info.json'))
    conf = {
        '/': {
            'request.dispatch': cherrypy.dispatch.MethodDispatcher(),
            'tools.sessions.on': True,
        }
    }
    cherrypy.tree.mount(ServiceCatalogManager(), '/', conf)
    cherrypy.config.update(conf)
    cherrypy.config.update({'server.socket_host': '0.0.0.0'})
    cherrypy.config.update({"server.socket_port": ServiceCatalogManager().getPort()})
    cherrypy.engine.start()
    cherrypy.engine.block()
