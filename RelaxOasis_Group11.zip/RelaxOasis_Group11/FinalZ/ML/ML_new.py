import paho.mqtt.client as PahoMQTT
import time
import json
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
import warnings
import requests
import os



service_catalog_url = os.getenv('SERVICE_CATALOG_URL', 'http://service-catalog:8080')
resource_catalog_url = os.getenv('RESOURCE_CATALOG_URL', 'http://resource-catalog-1:8081')





class ML:
		def __init__(self, clientID, topic, publish_topic, broker, port):
			self.clientID = clientID
			# create an instance of paho.mqtt.client
			self._paho_mqtt = PahoMQTT.Client(clientID, True) 

			# register the callback
			self._paho_mqtt.on_connect = self.myOnConnect
			self._paho_mqtt.on_message = self.myOnMessageReceived

			self.topic = topic
			self.publish_topic = publish_topic
			self.messageBroker = broker 

			self.received_people = False
			self.received_humidity = False
			self.received_temperature = False

			self.model = self.train_model()

			self.temperature = None
			self.humidity = None
			self.people_inside = None

			self.predicted_occupancy = 0  
                    
			self.message = {
							"e": [
								{
									"type": "safe_occupancy",
									"value": int(self.predicted_occupancy),
									"timestamp": time.time()
								}
							]
						}

		def start (self):
			# manage connection to broker
			self._paho_mqtt.connect(self.messageBroker, port)
			self._paho_mqtt.loop_start()
			# subscribe for a topic
			self._paho_mqtt.subscribe(self.topic, 0)

		def stop (self):
			self._paho_mqtt.unsubscribe(self.topic)
			self._paho_mqtt.loop_stop()
			self._paho_mqtt.disconnect()

		def myOnConnect (self, paho_mqtt, userdata, flags, rc):
			print ("Connected to %s with result code: %d" % (self.messageBroker, rc))
			print ("Connected with topic %s " % (self.topic))
			pass

		def myOnMessageReceived (self, paho_mqtt , userdata, msg):
			# A new message is received
			#print ("Topic:'" + msg.topic+"', QoS: '"+str(msg.qos)+"' Message: '"+str(msg.payload) + "'")
			topic = msg.topic
			message_json = json.loads(msg.payload)
			if "/".join(topic.rsplit("/", 2)[-2:]) == 'sensor_evo_1/NR':
				self.people_inside = message_json["e"][0]["value"]
				self.received_people = True
			elif topic.split("/")[-2] == 'sensorTH1':
				if message_json["e"][0]["type"] == "temperature":
					self.temperature = message_json["e"][0]["value"]
					self.received_temperature =  True
				elif message_json["e"][0]["type"] == "humidity":
					self.humidity = message_json["e"][0]["value"]
					self.received_humidity =  True

			if self.received_people and self.received_humidity and self.received_temperature:
				print()
				print('---------------------------------------------')
				print('Someone is trying to access the Relax Room...')
				time.sleep(1)
				print('  -   Temperature:               ', self.temperature)
				print('  -   Humidity:                  ', self.humidity)
				print('  -   Number of people inside:   ', self.people_inside)
				time.sleep(2)
				print('Evaluation of safe occupancy...')
				time.sleep(1)
				safe_occupancy = self.occupancy()
				print('Safe occupancy: ', safe_occupancy)
				self.received_temperature = False
				self.received_humidity = False
				self.received_people = False
    
		def occupancy(self):
			new_data = {'people_inside': self.people_inside, 'temperature': self.temperature, 'humidity': self.humidity}
			# Before making a prediction, check if temperature and humidity were received
			if self.temperature is None or self.humidity is None:
				print("------------Waiting for temperature and/or humidity data---------------")
				if self.temperature is None:
					print('self.temperature is None')
				elif self.humidity is None:
					print('self.humidity is None')
				elif self.people_inside is None:
					print('self.humidity is None')
			else:
				new_data['temperature'] = self.temperature
				new_data['humidity'] = self.humidity
				new_data['people_inside'] = self.people_inside

				# Convert new_data to a list for prediction
				new_data_list = [new_data['people_inside'], new_data['temperature'], new_data['humidity']]

				# Make prediction
				self.predicted_occupancy = self.model.predict([new_data_list])[0]
				self.publish_safe_occupancy()
			return int(self.predicted_occupancy)

		def publish_safe_occupancy(self):
				message = {
					"bn": self.publish_topic,
					"e": [
						{
							"type": "safe_occupancy",
							"value": int(self.predicted_occupancy),
							"timestamp": time.time()
						},
						{
							"type": "people_inside",
							"value": int(self.people_inside),
							"timestamp": time.time()
						}
					]
				}
				self._paho_mqtt.publish(self.publish_topic, json.dumps(message))
				print(f"Published safe occupancy: {message}")

		def train_model(self):
			# Sample data (replace with your actual data)
			data = {
				'people_inside':        [  10,   15,   11,    5,    8,   12,   9,    25,   17,   14,   17,    9,   25,   13,   19,   20,   25,    8,   28,   20,   16,   17,   10,   17,   21,   13,   18,   20,   20,   15],
				'temperature':          [22.2, 23.5, 20.7, 25.1, 24.3, 21.8, 26.2, 20.9, 19.5, 22.6, 24.1, 24.4, 24.2, 19.8, 20.3, 24.5, 20.4, 22.7, 19.9, 26.1, 22.8, 23.1, 21.0, 24.5, 20.6, 25.3, 19.7, 22.9, 21.4, 24.7],
				'humidity':             [50.2, 55.3, 60.5, 45.8, 50.9, 58.7, 62.1, 40.3, 48.2, 55.5, 45.6, 40.2, 57.3, 58.4, 44.5, 42.6, 56.7, 43.8, 42.1, 50.4, 51.7, 46.2, 57.1, 44.8, 53.6, 41.3, 49.5, 58.2, 47.4, 52.9],
				'safe_occupancy':       [  18,   15,   12,   17,   16,   16,   11,   25,   19,    16,   23,  26,   29,   19,   24,   25,   29,   22,   32,   22,   19,   17,   13,   24,   16,   25,    18,  22,   15,   24]}

			# Suppress the feature name warning (optional)
			warnings.filterwarnings("ignore")

			# Create a Pandas DataFrame for data manipulation
			df = pd.DataFrame(data)

			# Handle missing values (if any)
			df = df.dropna()  # Drops rows with missing values

			# Separate features and target variable
			X = df[['people_inside', 'temperature', 'humidity']]
			y = df['safe_occupancy']

			# Check for consistent data lengths
			if len(X) != len(y):
				print("Error: Inconsistent data lengths. Please ensure X and y have the same number of samples.")
				exit()

			# Split data into training and testing sets
			X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

			# Create and train the Random Forest model
			self.model = RandomForestRegressor(n_estimators=100, random_state=42)
			self.model.fit(X_train, y_train)

			return self.model

z = "conf_ML.json"

if __name__ == '__main__':
	service_catalog_info = "service_catalog_info.json"
	service_catalog_info = json.load(open(service_catalog_info))
	service_get_string = f"{service_catalog_url}/res_cat"
	rooms_all=json.loads(requests.get(service_get_string).text)
	print('Which relax room do you want to select?')
	N_rooms = len(rooms_all)
	for i in range(N_rooms):
		print(str(i+1) +' ---> '+ rooms_all[i]["owner"])

	while True:
		try:
			input_value = input('Enter the room number \n').strip()  # Remove leading/trailing spaces
			if not input_value:
				print('Error: No input provided, please enter a number')
				continue

			number_owner = int(input_value)

			if number_owner < 1 or number_owner > N_rooms:
				print('Error: Number out of range')
			else:
				name_owner = rooms_all[number_owner - 1]["owner"]
				print(f"Selected owner: {name_owner}")
				break

		except ValueError:
			print('Error: Invalid input, please enter a valid number')

	with open(z, 'r') as config_file:
		conf_ML = json.load(config_file)

	clientID = conf_ML["clientID"]+'_'+name_owner
	broker = conf_ML["broker"]
	port = conf_ML["port"]

	subscribe_topic = name_owner + '/room/#'          		 	#  topic to retrieve data from each sensor of name_owner/room
	publish_topic = name_owner + '/room/safe_occupancy'			#  topic to publish data about safe_occupancy
		
	test = ML(clientID, subscribe_topic, publish_topic, broker, port)
	test.start()

	a = 0
	while (a < 50):
		a += 1
		time.sleep(3)

	test.stop()
