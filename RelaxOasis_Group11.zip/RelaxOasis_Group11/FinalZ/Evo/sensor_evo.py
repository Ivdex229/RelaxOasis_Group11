import json
import time
import random
from MyMQTT import MyMQTT
import requests
import sys
import paho.mqtt.client as PahoMQTT
import time
import os

service_catalog_url = os.getenv('SERVICE_CATALOG_URL', 'http://service-catalog:8080')
resource_catalog_url = os.getenv('RESOURCE_CATALOG_URL', 'http://resource-catalog-1:8081')






class SensorControl_Subscriber:
    def __init__(self, clientID, topic, broker):
        self.clientID = clientID
        # create an instance of paho.mqtt.client
        self._paho_mqtt = PahoMQTT.Client(clientID, True) 

        # register the callback
        self._paho_mqtt.on_connect = self.myOnConnect
        self._paho_mqtt.on_message = self.myOnMessageReceived

        self.topic = topic
        self.messageBroker = broker 
        self.safe_occupancy = 0

    def start (self):
        #manage connection to broker
        self._paho_mqtt.connect(self.messageBroker, 1883)
        self._paho_mqtt.loop_start()
        # subscribe for a topic
        self._paho_mqtt.subscribe(self.topic, 0)

    def stop (self):
        self._paho_mqtt.unsubscribe(self.topic)
        self._paho_mqtt.loop_stop()
        self._paho_mqtt.disconnect()

    def myOnConnect (self, paho_mqtt, userdata, flags, rc):
        print ("Connected to %s with result code: %d" % (self.messageBroker, rc))
        print ("Connected with topic %s " % (self.topic))
        pass

    def myOnMessageReceived (self, paho_mqtt , userdata, msg):
        # A new message is received
        # print ("Topic:'" + msg.topic+"', QoS: '"+str(msg.qos)+"' Message: '"+str(msg.payload) + "'")
        max_people_allowed = 25
        self.safe_occupancy = json.loads(msg.payload)['e'][0]['value']
        self.people_inside = json.loads(msg.payload)['e'][1]['value']
        
        if self.people_inside < int(max_people_allowed) and self.people_inside < self.safe_occupancy:
            print(f'Welcome in the Relax Oasis,now there are {self.people_inside} people inside, the maximum capacity is fixed to {max_people_allowed}')
            # lcd_thread = threading.Thread(target=lcd.main, args=(f'User {simulated_CF}' ,'is authorized',))
            # lcd_thread.start()
            # time.sleep(2)
            # lcd_thread = threading.Thread(target=lcd.main, args=(' Welcome in the','   Relax Oasis',))
            # lcd_thread.start()
            if self.safe_occupancy < int(max_people_allowed):
                print (f'The evaluated safe occupancy is {int(self.safe_occupancy)} so now only others {int(self.safe_occupancy)-self.people_inside} can enter in the room')
            else:
                print (f'The evaluated safe occupancy overcomes the fixed maximum capacity so now only others {int(max_people_allowed)-self.people_inside} can enter in the room')
        else:
            print('but we are sorry,the oasis is full')
            # lcd_thread = threading.Thread(target=lcd.main, args=('but we are sorry,','Oasis is full',))
            # lcd_thread.start()

class SensorControl_Publisher:
    def __init__(self, clientID, sensortype, sensorID, measure, broker, port, topic):
        self.clientID = clientID
        print('CLIENT PUB', self.clientID)
        self.sensortype = sensortype
        self.sensorID = sensorID
        self.measure = measure
        self.topic = topic
        self.client_pub = MyMQTT(self.sensorID, broker, port, None)

        self.__message = {
            'bn': self.topic,
            'e': [
                {
                    'type': self.sensortype,
                    'unit': self.measure,
                    'timestamp': '',
                    'value': ' '
                }
            ]
        }

    def start(self):
        self.client_pub.start()

    def stop(self):
        self.client_pub.stop()

    def publish(self, value):
        self.__message['e'][0]['type'] = 'access'
        self.__message['e'][0]['value'] = value
        self.__message['e'][0]['timestamp'] = str(time.time())
        self.client_pub.myPublish(self.topic, json.dumps(self.__message))
        #print("published\n" + json.dumps(self.__message))
    
    def register_user(self, user_data):
        with open('resource_catalog_users_1.json', 'r') as user_file:
            users = json.load(user_file)

        # Assuming user_data is a dictionary with user information
        users.append(user_data)

        with open('resource_catalog_users_1.json', 'w') as user_file:
            json.dump(users, user_file)
            
setting_file= "conf_evo.json"
service_file = "service_catalog_info.json"

def registration(setting_file, service_file, number_owner, name_owner):
    with open(setting_file,"r") as f1:      # setting_file = "conf_light.json"
        conf=json.loads(f1.read())

    with open(service_file,"r") as f2:      # service_file = "service_catalog_info.json"
        conf_service=json.loads(f2.read())
    
    # info about resource_catalogue
    # GET request to service_catalog
    requeststring = f"{service_catalog_url}/N_res_cat?N={int(number_owner) - 1}"
    r = requests.get(requeststring)
    print('REQUESTED INFO ABOUT RESOURCE CATALOGUE')
    print()
    
    rc = json.loads(r.text)
    print('RESOURCE CATALOGUE: ',rc)
    
    rc_ip = rc["ip_address"]
    rc_ip_port = rc["ip_port"]
    rc_broker = rc["broker"]
    rc_broker_port = rc["broker_port"]
    rc_owner = rc["owner"]            # ex. relax_room_politecnico
    rc_basetopic = rc["base_topic"]   # ex. relax_room_iot
    
    sensor_model=conf["sensor_model"]

    # info about base topic
    # GET request to service_catalog
    requeststring = f"{service_catalog_url}/base_topic"
    sbt = requests.get(requeststring)
    service_b_t = json.loads(sbt.text)
    
    # add new devices
    # POST request to resource_catalog
    poststring = f"{resource_catalog_url}/device"

    topic=[]
    body=[]
    index=0
    for i in conf["sensor_type"]:
        print('MEASURE: ', i)
        topic.append(name_owner+'/'+rc_basetopic+"/"+i+"/"+conf["sensor_id"])
        body_dic= {
        "owner": name_owner,
        "sensor_id":conf['sensor_id'],
        "sensor_type":conf['sensor_type'],
            "measure":conf["measure"][index],
            "end-points":{
                "basetopic":service_b_t,
                "complete_topic":topic,
                "broker":rc["broker"],
                "port":rc["broker_port"]
            }
        }
        body.append(body_dic)
        requests.post(poststring, json.dumps(body[index]))
        print('BODY: ', json.dumps(body[index]))
        index=index+1
    print('POSTED INFO ABOUT DEVICES')
    print()

    return rc_basetopic, conf["sensor_type"], conf["sensor_id"], topic, conf["measure"], rc_broker, rc_broker_port, sensor_model

if __name__ == "__main__":
    
    service_catalog_info = "service_catalog_info.json"
    service_catalog_info = json.load(open(service_catalog_info))
    service_get_string = f"{service_catalog_url}/res_cat"
    rooms_all=json.loads(requests.get(service_get_string).text)
    print('Which relax room do you want to select?')
    N_rooms = len(rooms_all)
    for i in range(N_rooms):
        print(str(i+1) +' ---> '+ rooms_all[i]["owner"])

    while True:
        try:
            input_value = input('Enter the room number \n').strip()  # Remove leading/trailing spaces
            if not input_value:
                print('Error: No input provided, please enter a number')
                continue

            number_owner = int(input_value)

            if number_owner < 1 or number_owner > N_rooms:
                print('Error: Number out of range')
            else:
                name_owner = rooms_all[number_owner - 1]["owner"]
                print(f"Selected owner: {name_owner}")
                break

        except ValueError:
            print('Error: Invalid input, please enter a valid number')

    # ------------ MQTT -----------------------
    #conf_evo.json service_catalog_info.json resource_catalog_users.json
    clientID, sensortype, sensorID, topic, measure, broker, port, sensor_model = registration('conf_evo.json', 'service_catalog_info.json', number_owner, name_owner)
    list_CF_da_testare = ["efg345", "hij678", "klm901", "nop234", "qrs567", "tuv890", "wxy123", "zab456", "cde789", "fgh012", "ijk345", "lmn678", "opq901", "rst234", "uvw567", "abc123", "def456", "ghi789", "jkl012", "mno345", "pqr678", "stu901", "vwx234", "yza567", "bcd890"]
    random.shuffle(list_CF_da_testare)
    # questa lista contiene tutti i codici degli utenti che provano ad entrare
    with open("resource_catalog_users_1.json", "r") as json_file:
        data = json.load(json_file)
    list_unique_codes_accepted =[user["unique_code"] for user in data]
    
    print()
    print()
    
    # Example setup
    clientID = "mysensorID"+'_'+name_owner
    topic = name_owner + "/room/fiscal_code/sensor_evo_1/NR"
    list_CF_da_testare = ["efg345", "hij678", "klm901", "nop234", "qrs567", "tuv890", "wxy123", "zab456", "cde789", "fgh012", "ijk345", "lmn678", "opq901", "rst234", "uvw567", "abc123", "def456", "ghi789", "jkl012", "mno345", "pqr678", "stu901", "vwx234", "yza567", "bcd890"]
    people_inside = 10
    publisher = SensorControl_Publisher(clientID, sensortype, sensorID, measure, broker, port, topic)
    publisher.start()    
    
    # Create instances of SensorControl_Subscriber
    # At each call we evaluate the max number of people allowed
    max_people_allowed = 20
    topic_subscriber = name_owner + '/room/safe_occupancy'
    
    test = SensorControl_Subscriber("mysubtestsubIOT_evo"+'_'+name_owner ,topic_subscriber,"test.mosquitto.org")
    test.start()
    time.sleep(2)
    try:
        for _ in range(len(list_CF_da_testare)):
            simulated_CF = random.choice(list_CF_da_testare) 
            print('Simulated CF = {}'.format(simulated_CF))
            if simulated_CF  not in list_unique_codes_accepted:
                print(f'User {simulated_CF} not authorized, access denied')
                # lcd_thread = threading.Thread(target=lcd.main, args=(f'User {simulated_CF}', 'Access denied',))
                # lcd_thread.start()
            else:
                print(f'User {simulated_CF} authorized')
                people_inside = people_inside + 1
                publisher.publish(str(people_inside))
            time.sleep(10)
            print()
    finally:
        publisher.stop()
        test.stop()
