import telepot
from telepot.loop import MessageLoop
from telepot.namedtuple import InlineKeyboardMarkup, InlineKeyboardButton
import json
import requests
import time
import os

service_catalog_url = os.getenv('SERVICE_CATALOG_URL', 'http://service-catalog:8080')
resource_catalog_url = os.getenv('RESOURCE_CATALOG_URL', 'http://resource-catalog-1:8081')

class EchoBot1:
    def __init__(self, token, service_catalog_info_path, thingspeak_config_path):
        # Load service catalog info
        with open(service_catalog_info_path, 'r') as file:
            self.service_catalog_info = json.load(file)
        
        self.tokenBot = token
        self.bot = telepot.Bot(self.tokenBot)
        MessageLoop(self.bot, {'chat': self.on_chat_message,
                               'callback_query': self.on_callback_query}).run_as_thread()
        
        self.service_get_string = f"{service_catalog_url}/res_cat"
        self.rooms_all = self.fetch_rooms()
        self.reset_temp_variables()
        self.ownerscelto = ''  # Initialize the owner chosen 


        # Load ThingSpeak configuration
        with open(thingspeak_config_path, 'r') as file:
            thingspeak_config = json.load(file)
            self.api_key = thingspeak_config['key']
            self.thingspeak_url = thingspeak_config['url_channels']

    def fetch_rooms(self):
        response = requests.get(self.service_get_string)
        response.raise_for_status()
        return json.loads(response.text)

    def reset_temp_variables(self):
        self.rooms = []
        self.chosen_owner = False
        self.requested_owner = ''
        self.chosen_room = False
        self.requested_room = ''
        self.r = {}
        self.new_owner_flag = False
        self.name_new_owner = ''
        self.nr_last_room = len(self.rooms_all)
        self.new_channel_name = ''

    def on_chat_message(self, msg):
        content_type, chat_type, chat_ID = telepot.glance(msg)
        message = msg['text']

        if message == "/start":
            self.rooms_all = self.fetch_rooms()
            self.bot.sendMessage(chat_ID, text='Command /operation or /new_owner')
        elif message == "/operation":
            self.update_rooms()
            self.show_owners(chat_ID)

        elif message == "/new_owner":
            self.bot.sendMessage(chat_ID, text='Please enter the password:')
            self.awaiting_password = True
        elif self.awaiting_password:
            if message == "manager_room":
                self.awaiting_password = False
                self.prompt_new_owner(chat_ID)
            else:
                self.awaiting_password = False
                self.bot.sendMessage(chat_ID, text='Incorrect password. Command /operation or /new_owner')
        elif self.new_owner_flag:
            self.create_new_owner(chat_ID, message)
        else:
            self.bot.sendMessage(chat_ID, text="Command not supported")

    def show_owners(self, chat_ID):
        buttons = [
            [InlineKeyboardButton(text=room['owner'], callback_data=room['owner'])]
            for room in self.rooms
        ]
        keyboard = InlineKeyboardMarkup(inline_keyboard=buttons)
        self.bot.sendMessage(chat_ID, text='Which owner are you interested in?', reply_markup=keyboard)

    def prompt_new_owner(self, chat_ID):
        self.bot.sendMessage(chat_ID, text='Insert the name of the new Relax Room')
        self.new_owner_flag = True

    def create_new_owner(self, chat_ID, owner_name):
        self.name_new_owner = owner_name
        self.nr_last_room += 1
        self.on_create_new_room(chat_ID)
        self.new_owner_flag = False

    def on_callback_query(self, msg):
        query_ID, chat_ID, query_data = telepot.glance(msg, flavor='callback_query')
        message = query_data

        if not self.chosen_owner:
            self.select_owner(chat_ID, message)
        elif self.chosen_owner and not self.chosen_room:
            self.select_room(chat_ID, message)
        elif self.chosen_owner and self.chosen_room:
            self.display_sensor_data(chat_ID, message)

    def select_owner(self, chat_ID, owner):
        self.requested_owner = owner
        print(f"Selected owner: {self.requested_owner}")  # Print selected owner
        self.chosen_owner = True
        self.ownerscelto = owner  # Store the selected owner's name
        buttons = []
        for own in self.rooms:
            if own['owner'] == self.requested_owner:
                buttons.extend(
                    [InlineKeyboardButton(text=room["room_name"], callback_data=room["room_name"])]
                    for room in own['rooms']
                )
        keyboard = InlineKeyboardMarkup(inline_keyboard=buttons)
        self.bot.sendMessage(chat_ID, text='Which room are you interested in?', reply_markup=keyboard)

    def select_room(self, chat_ID, room_name):
        self.requested_room = room_name
        self.chosen_room = True
        for owner in self.rooms:
            if owner['owner'] == self.requested_owner:
                for room in owner['rooms']:
                    if room['room_name'] == self.requested_room:
                        self.r = room
        self.show_sensors(chat_ID)

    def show_sensors(self, chat_ID):
        buttons = [
            [InlineKeyboardButton(text=self.get_sensor_button_text(dev), callback_data=dev)]
            for dev in self.r.get('room_sensors', [])
        ]
        keyboard = InlineKeyboardMarkup(inline_keyboard=buttons)
        if buttons:
            self.bot.sendMessage(chat_ID, text='Choose a sensor', reply_markup=keyboard)
        else:
            self.bot.sendMessage(chat_ID, text='No sensor available, write /operation to ask for data or /new_owner to create a new owner')

    def get_sensor_button_text(self, sensor):
        icons = {
            'temperature': '🌡️',
            'humidity': '💧',
            'noise': '🔊',
            'brightness': '💡'
        }
        return f"{icons.get(sensor, '')} {sensor}"

    def display_sensor_data(self, chat_ID, sensor):
        for dev in self.r.get('room_sensors', []):
            if sensor == dev:
                conf_service = self.load_sensor_config(sensor)
                if conf_service:
                    index = self.get_owner_index()
                    base_url = os.getenv(f'{sensor}_SENSOR_BASE_URL', 'http://localhost')
                    base_port = int(os.getenv(f'{sensor}_SENSOR_PORT', '8000'))
                    kirekhar = f"{base_url}:{str(int(base_port) + index)}"
                    request_string = f"{kirekhar}/{sensor}"
                    value = requests.get(request_string)
                    self.reset_temp_variables()
                    self.bot.sendMessage(chat_ID, text=value.text)
                    iframe_url = self.get_thingspeak_iframe_url(sensor)
                    self.bot.sendMessage(chat_ID, text=f"Here is the plot for {sensor}:\n{iframe_url}")
                    self.bot.sendMessage(chat_ID, text='Write /operation to ask for data or /new_owner to create a new owner')

    def load_sensor_config(self, sensor):
        config_files = {
            "brightness": "conf_light.json",
            "noise": "conf_noise.json",
            "temperature": "conf_temperature.json",
            "humidity": "conf_humidity.json"
        }
        file_name = config_files.get(sensor)
        if not file_name:
            return None

        config_path = os.path.join(current_dir, file_name)
        with open(config_path, "r") as f2:
            return json.load(f2)

    def get_owner_index(self):
        for i, room in enumerate(self.rooms_all):
            if room["owner"] == self.requested_owner:
                return i + 1
        return 0

    def get_channel_id(self):
        response = requests.get(self.thingspeak_url, params={'api_key': self.api_key})
        if response.status_code == 200:
            channels = response.json()
            if channels:
                for channel in channels:
                    if channel['name'] == self.ownerscelto:
                        return channel['id']
        else:
            raise ConnectionError(f"Failed to fetch channels: {response.status_code}")

    
    def get_thingspeak_iframe_url(self, sensor_type):
        channel_id = self.get_channel_id()
        
        sensor_map = {
            'temperature': '1',
            'humidity': '2',
            'noise': '3',
            'brightness': '4'
        }
        field_number = sensor_map.get(sensor_type, '1')
        return f'https://thingspeak.com/channels/{channel_id}/charts/{field_number}?bgcolor=%23ffffff&color=%23d62020&dynamic=true&results=60&type=line&update=15'

    def update_rooms(self):
        self.rooms_all = self.fetch_rooms()
        self.rooms = []
        for entry in self.rooms_all:
            devices = self.fetch_devices(entry)
            sensors = [type for dev in devices for type in dev["sensor_type"] if type != 'fiscal_code' and dev["owner"] == entry["owner"]]
            room = {
                "room_name": entry["base_topic"],
                "room_sensors": sensors
            }
            self.add_room(entry['owner'], room)

    def fetch_devices(self, entry):
        request_string = f"{resource_catalog_url}/alldevices"
        response = requests.get(request_string)
        response.raise_for_status()
        return json.loads(response.text)

    def add_room(self, owner, room):
        for own in self.rooms:
            if own['owner'] == owner:
                own['rooms'].append(room)
                return
        self.rooms.append({'owner': owner, 'rooms': [room]})

    def on_create_new_room(self, chat_ID):
        post_url = f"{service_catalog_url}"
        settings_file_path = os.path.join(current_dir, 'resource_catalog_settings_1.json')
        with open(settings_file_path, 'r') as file:
            settings_data = json.load(file)
        settings_data['owner'] = f"relax_room_{self.name_new_owner}"
        self.post_new_room(post_url, settings_data)
        self.bot.sendMessage(chat_ID, text='New relax room created!')
        self.bot.sendMessage(chat_ID, text='Write /operation to ask for data or /new_owner to create a new owner')

    def post_new_room(self, url, data):
        headers = {'Content-Type': 'application/json'}
        requests.post(url, json=data, headers=headers)

if __name__ == "__main__":
    current_dir = os.path.dirname(os.path.abspath(__file__))
    conf_file_path = os.path.join(current_dir, "conf_bot_telegram.json")
    with open(conf_file_path, "r") as file:
        conf = json.load(file)

    token = conf["telegramToken"]
    service_catalog_info_path = os.path.join(current_dir, "service_catalog_info.json")
    thingspeak_config_path = os.path.join(current_dir, "conf_thinkgspeak.json")

    bot = EchoBot1(token, service_catalog_info_path, thingspeak_config_path)
    
    channel_id = bot.get_channel_id()
    
    print("Bot started ...")
    while True:
        time.sleep(3)
