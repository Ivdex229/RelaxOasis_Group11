# Import necessary libraries
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import warnings
import matplotlib.pyplot as plt
import time
import json
from MyMQTT import *
import requests
import os

service_catalog_url = os.getenv('SERVICE_CATALOG_URL', 'http://service-catalog:8080')
resource_catalog_url = os.getenv('RESOURCE_CATALOG_URL', 'http://resource-catalog-1:8081')

class ML_Subscriber:
    def __init__(self,clientID, broker, port, topic):
        self.model = self.train_model()
        self.client = MyMQTT(clientID, broker, port, self)
        self.topic = topic
        self.temperature = None
        self.humidity = None
        self.both_messages = 0
        self.received_temperature = False
        self.received_humidity = False
        self.received_people = False
        self.nr = 0

    def notify(self, topic, payload):
        message_json = json.loads(payload)
        if "/".join(topic.rsplit("/", 2)[-2:]) == 'sensor_evo_1/NR':
            self.people_inside = message_json["e"][0]["value"]
            self.received_people = True
        elif topic.split("/")[-1] == 'sensorTH1':
            if message_json["e"][0]["type"] == "temperature":
                self.temperature = message_json["e"][0]["value"]
                self.received_temperature =  True
            elif message_json["e"][0]["type"] == "humidity":
                self.humidity = message_json["e"][0]["value"]
                self.received_humidity =  True

        if self.received_people and self.received_humidity and self.received_temperature:
            print('Someone is trying to access the Relax Room...')
            time.sleep(1)
            print('  -   Temperature:               ', self.temperature)
            print('  -   Humidity:                  ', self.humidity)
            print('  -   Number of people inside:   ', self.people_inside)
            time.sleep(2)
            print('Evaluation of safe occupancy...')
            time.sleep(2)
            self.occupancy()
            self.received_temperature = False
            self.received_humidity = False
            self.received_people = False
            print()

    def occupancy(self):
        new_data = {'people_inside': self.people_inside, 'temperature': self.temperature, 'humidity': self.humidity}
        # Before making a prediction, check if temperature and humidity were received
        if self.temperature is None or self.humidity is None:
            print("------------Waiting for temperature and/or humidity data---------------")
            if self.temperature is None:
                print('self.temperature is None')
            if self.humidity is None:
                print('self.humidity is None')
        else:
            new_data['temperature'] = self.temperature
            new_data['humidity'] = self.humidity

            # Convert new_data to a list for prediction
            new_data_list = [new_data['people_inside'], new_data['temperature'], new_data['humidity']]

            # Make prediction
            predicted_occupancy = self.model.predict([new_data_list])[0]

            # ________________________________

            print("Predicted safe occupancy of the room:", int(predicted_occupancy))

        return predicted_occupancy


    def startSim(self):
        self.client.start()
        self.client.mySubscribe(self.topic)
        #self.client.mySubscribe(self.topic2)

    def stopSim(self):
        self.client.myUnsubscribe(self.topic)
        #self.client.myUnsubscribe(self.topic2)
        self.client.stop()
    
    def train_model(self):
        # Sample data (replace with your actual data)
        data = {
            'people_inside':        [  10,   15,   11,    5,    8,   12,   9,    25,   17,   14,   17,    9,   25,   13,   19,   20,   25,    8,   28,   20,   16,   17,   10,   17,   21,   13,   18,   20,   20,   15],
            'temperature':          [22.2, 23.5, 20.7, 25.1, 24.3, 21.8, 26.2, 20.9, 19.5, 22.6, 24.1, 24.4, 24.2, 19.8, 20.3, 24.5, 20.4, 22.7, 19.9, 26.1, 22.8, 23.1, 21.0, 24.5, 20.6, 25.3, 19.7, 22.9, 21.4, 24.7],
            'humidity':             [50.2, 55.3, 60.5, 45.8, 50.9, 58.7, 62.1, 40.3, 48.2, 55.5, 45.6, 40.2, 57.3, 58.4, 44.5, 42.6, 56.7, 43.8, 42.1, 50.4, 51.7, 46.2, 57.1, 44.8, 53.6, 41.3, 49.5, 58.2, 47.4, 52.9],
            'safe_occupancy':       [  18,   15,   12,   17,   16,   16,   11,   25,   19,    16,   23,  26,   29,   19,   24,   25,   29,   22,   32,   22,   19,   17,   13,   24,   16,   25,    18,  22,   15,   24]}

        # Suppress the feature name warning (optional)
        warnings.filterwarnings("ignore")

        # Create a Pandas DataFrame for data manipulation
        df = pd.DataFrame(data)

        # Handle missing values (if any)
        df = df.dropna()  # Drops rows with missing values

        # Separate features and target variable
        X = df[['people_inside', 'temperature', 'humidity']]
        y = df['safe_occupancy']

        # Check for consistent data lengths
        if len(X) != len(y):
            print("Error: Inconsistent data lengths. Please ensure X and y have the same number of samples.")
            exit()

        # Split data into training and testing sets
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

        # Create and train the Random Forest model
        self.model = RandomForestRegressor(n_estimators=100, random_state=42)
        self.model.fit(X_train, y_train)

        # Make predictions on test data
        y_predicted = self.model.predict(X_test)

        # Calculate Mean Squared Error
        mse = mean_squared_error(y_test, y_predicted)
        
        return self.model
    
def owner_topic(topic, owner):
    topic_divided = topic.split("/")
    topic_divided[0] = owner
    return "/".join(topic_divided)
zighi="conf_ML.json"
if __name__ == '__main__':
    # Instantiate and start the THSubscriber to receive temperature and humidity data
    with open(zighi, 'r') as config_file:
        conf_ML = json.load(config_file)
    clientID = conf_ML["clientID"]
    broker = conf_ML["broker"]
    port = conf_ML["port"]
    topic = conf_ML["topic"]
    
    service_catalog_info = "service_catalog_info.json"
    service_catalog_info = json.load(open(service_catalog_info))
    service_get_string = f"{service_catalog_url}/res_cat"
    rooms_all=json.loads(requests.get(service_get_string).text)
    print('Which relax room do you want to select?')
    N_rooms = len(rooms_all)
    for i in range(N_rooms):
        print(str(i+1) +' ---> '+ rooms_all[i]["owner"])
    name_owner = input('Enter the room number \n')  # es. 1 o 2 o ...
    owner = rooms_all[int(name_owner)-1]["owner"]        # es. relax_room_politecnico o relax_room_moncalieri o ...
        
    topic = owner_topic(topic, owner)
    
    subscriber = ML_Subscriber(clientID, broker, port, topic)
    subscriber.startSim()
    while True:
        time.sleep(15)