
import os
from MyMQTT import *
import time
import json
import random
from simplePublisher import *
from simpleSubscriber import *
import requests
import sys
#import lcd1 as lcd
import threading
from pprint import pprint

#from RPLCD.i2c import CharLCD #è commentato perchè prima proviamo a stampare tutto senza usare hardware come schermi lcd  ###pip install RPLCD
service_catalog_url = os.getenv('SERVICE_CATALOG_URL', 'http://service-catalog:8080')
resource_catalog_url = os.getenv('RESOURCE_CATALOG_URL', 'http://resource-catalog-1:8081')

class SensorControl(MyPublisher):
    def __init__(self, clientID, sensortype, sensorID, measure, broker, port, topic):
        self.clientID = clientID
        self.sensortype = sensortype
        self.sensorID = sensorID
        self.measure = measure
        self.topic = topic
        self.client = MyMQTT(self.sensorID, broker, port, None)

        self.__message = {
            'bn': self.topic,
            'e': [
                {
                    'type': self.sensortype,
                    'unit': self.measure,
                    'timestamp': '',
                    'value': ' '
                }
            ]
        }

    def start(self):
        self.client.start()

    def stop(self):
        self.client.stop()

    def publish(self, value):
        message = self.__message
        message['e'][0]['value'] = value
        message['e'][0]['timestamp'] = str(time.time())
        self.client.myPublish(self.topic, json.dumps(message))
        print("published\n" + json.dumps(message))

    user_data="resource_catalog_users_1.json"

    def register_user(self, user_data):
        with open('resource_catalog_users_1.json', 'r') as user_file:
            users = json.load(user_file)

        # Assuming user_data is a dictionary with user information
        users.append(user_data)

        with open('resource_catalog_users_1.json', 'w') as user_file:
            json.dump(users, user_file)

setting_file= "conf_evo.json"
service_file = "service_catalog_info.json"
def registration(setting_file, service_file,number_owner, name_owner):
    with open(setting_file,"r") as f1:    
        conf=json.loads(f1.read())

    with open(service_file,"r") as f2:    
        conf_service=json.loads(f2.read())
    
    requeststring = f"{service_catalog_url}/N_res_cat?N={int(number_owner) - 1}"

        
    r = requests.get(requeststring)
    print('REQUESTED INFO ABOUT RESOURCE CATALOGUE')
    print()
    rc = json.loads(r.text)
    print('RESOURCE CATALOGUE: ', rc)
    rc_ip = rc["ip_address"]
    rc_ip_port = rc["ip_port"]
    poststring = f"{resource_catalog_url}/device"
    rc_broker = rc["broker"]
    rc_broker_port = rc["broker_port"]
    rc_owner = rc["owner"]            # ex. relax_room_politecnico
    rc_basetopic = rc["base_topic"]   # ex. room
    
    #sensor_type=""
    #for entry in conf["sensor_type"]:
    #    sensor_type=sensor_type+entry+"_"
    
    sensor_model=conf["sensor_model"]
    #sensor_measure=""
    #for entry in conf["measure"]:
    #    sensor_measure=sensor_measure+"_"+entry

    requeststring = f"{service_catalog_url}/base_topic"
    sbt=requests.get(requeststring)

    service_b_t=json.loads(sbt.text)
    topic=[]
    body=[]
    index=0
    for i in conf["sensor_type"]:
        print('MEASURE: ', i)
        topic.append(name_owner + '/' + rc_basetopic + "/" + i + "/" + conf["sensor_id"])
        body_dic = {
            "owner": name_owner,
            "sensor_id": conf['sensor_id'],
            "sensor_type": conf['sensor_type'],
            "measure": conf["measure"][index],
            "end-points": {
                "basetopic": service_b_t,
                "complete_topic": topic,
                "broker": rc["broker"],
                "port": rc["broker_port"]
            }
        }
        body.append(body_dic)
        requests.post(poststring, json.dumps(body[index]))
        print('BODY: ', json.dumps(body[index]))
        index = index + 1
    print('POSTED INFO ABOUT DEVICES')
    print()

    return rc_basetopic, conf["sensor_type"], conf["sensor_id"], topic, conf["measure"], rc_broker, rc_broker_port, sensor_model

if __name__ == "__main__":
    service_catalog_info = "service_catalog_info.json"
    service_catalog_info = json.load(open(service_catalog_info))
    service_get_string = f"{service_catalog_url}/res_cat"
    rooms_all = json.loads(requests.get(service_get_string).text)
    print('Which relax room do you want to select?')
    N_rooms = len(rooms_all)
    for i in range(N_rooms):
        print(str(i + 1) + ' ---> ' + rooms_all[i]["owner"])
    number_owner = input('Enter the room number \n')
    name_owner = rooms_all[int(number_owner) - 1]["owner"]
    # ------------ MQTT -----------------------
    clientID, sensortype, sensorID, topic, measure, broker, port, sensor_model = registration(setting_file, service_file, number_owner,name_owner)

    # Create instances of SensorControl
    index = 0
    Sensor = []
    for i in sensortype:
        Sensor.append(SensorControl(clientID +'NR', i, sensorID, measure[index], broker, port, str(topic[index]+'/NR')))
        Sensor.append(SensorControl(clientID +'CF', i, sensorID, measure[index], broker, port, str(topic[index]+'/CF')))
        Sensor[index].start()
        index += 1
        
    for element in range(len(Sensor)):
        print('SENSOR: ', Sensor[element].topic)
    
    list_CF_da_testare = ["efg345", "hij678", "klm901", "nop234", "qrs567", "tuv890", "wxy123", "zab456", "cde789", "fgh012", "ijk345", "lmn678", "opq901", "rst234", "uvw567", "abc123", "def456", "ghi789", "jkl012", "mno345", "pqr678", "stu901", "vwx234", "yza567", "bcd890"]
    random.shuffle(list_CF_da_testare)
    # questa lista contiene tutti i codici degli utenti che provano ad entrare
    with open("resource_catalog_users_1.json", "r") as json_file:
        data = json.load(json_file)
    list_unique_codes_accepted =[user["unique_code"] for user in data]
    
    print()
    print()

    counter=0
    
    # PER SEMPLICITA' SIMULIAMO I SENSORI
    for index in range(len(list_CF_da_testare)):
        # Simulate evo data instead of using actual sensor
        people_inside = 10 + counter
        simulated_CF = list_CF_da_testare[index]
        print('Simulated CF = {}'.format(simulated_CF))
        Sensor[0].publish(str(people_inside))
        Sensor[1].publish(str(list_CF_da_testare))

        # At each call we evaluate the max number of people allowed
        # max_people_allowed1 = ML_new.occupancy(simulated_CF, people_inside)
        max_people_allowed = 20

        if simulated_CF not in list_unique_codes_accepted:
            print(f'User {simulated_CF} not authorized, access denied')
            # lcd_thread = threading.Thread(target=lcd.main, args=(f'User {simulated_CF}', 'Access denied',))
            # lcd_thread.start()
        else:
            print(f'User {simulated_CF} authorized')
            # lcd_thread = threading.Thread(target=lcd.main, args=(f'User {simulated_CF}' ,'Access authorized',))
            # lcd_thread.start()
            # time.sleep(1)
            if counter < int(max_people_allowed):
                counter += 1
                print(
                    f'Welcome in the Relax Oasis,now there are {people_inside + 1} people inside, the maximum capacity is fixed to {max_people_allowed}')
                print(f'in the best condition maximum {int(max_people_allowed) - people_inside - 1} people allowed')
                # lcd_thread = threading.Thread(target=lcd.main, args=(f'User {simulated_CF}' ,'is authorized',))
                # lcd_thread.start()
                # time.sleep(2)
                # lcd_thread = threading.Thread(target=lcd.main, args=(' Welcome in the','   Relax Oasis',))
                # lcd_thread.start()
            else:
                print('but we are sorry,the oasis is full')
                # lcd_thread = threading.Thread(target=lcd.main, args=('but we are sorry,','Oasis is full',))
                # lcd_thread.start()
            # qui registriamo
        print()
        time.sleep(15)