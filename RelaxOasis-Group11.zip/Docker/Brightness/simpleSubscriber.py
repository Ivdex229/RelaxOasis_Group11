import paho.mqtt.client as PahoMQTT
import time


class MySubscriber:
	def __init__(self, clientID, topic, broker):
		self.clientID = clientID
		# create an instance of paho.mqtt.client
		self._paho_mqtt = PahoMQTT.Client(clientID, True) 

		# register the callback
		self._paho_mqtt.on_connect = self.myOnConnect
		self._paho_mqtt.on_message = self.myOnMessageReceived

		self.topic = topic
		self.messageBroker = broker 

	def start (self):
		#manage connection to broker
		self._paho_mqtt.connect(self.messageBroker, 1883)
		self._paho_mqtt.loop_start()
		# subscribe for a topic
		self._paho_mqtt.subscribe(self.topic, 0)

	def stop (self):
		self._paho_mqtt.unsubscribe(self.topic)
		self._paho_mqtt.loop_stop()
		self._paho_mqtt.disconnect()

	def myOnConnect (self, paho_mqtt, userdata, flags, rc):
		print ("Connected to %s with result code: %d" % (self.messageBroker, rc))
		print ("Connected with topic %s " % (self.topic))
		pass

	def myOnMessageReceived (self, paho_mqtt , userdata, msg):
		# A new message is received
		print ("Topic:'" + msg.topic+"', QoS: '"+str(msg.qos)+"' Message: '"+str(msg.payload) + "'")


if __name__ == "__main__":
	test = MySubscriber("mysubtestsubIOT_ciao","relax_room_iot/resource/sensor_value/+/humidity/+","test.mosquitto.org")
	test.start()
	print('START....')

	a = 0
	while (a < 30):
		a += 1
		time.sleep(1)

	test.stop()
